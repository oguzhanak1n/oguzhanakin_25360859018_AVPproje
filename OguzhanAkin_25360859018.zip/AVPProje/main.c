#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
const float cekimIvmeleri[8]={3.7, 8.87, 9.81, 3.71, 24.79, 10.44, 8.69, 11.15};
const char* Gezegenler[8]={"Merkur","Venus","Dunya","Mars","Jupiter","Saturn","Uranus","Neptun"};
void serbest_dusme(float t,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float h=(0.5) * *(ivme+i) * (t*t);
        printf("%s: %f Metre\n",*(gez+i),h);
    }
}
void yukari_atis(float v,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float h=(v*v)/(2* *(ivme+i));
        printf("%s: %f Metre\n",*(gez+i),h);
    }
}
void agirlik(float m,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float G=m* *(ivme+i);
        printf("%s: %f Newton\n",*(gez+i),G);
    }
}
void kPotansiyel(float h,float m,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float enerji=h*m* *(ivme+i);
        printf("%s: %f Joule\n",*(gez+i),enerji);
    }
}
void hidrobas(float x,float v, float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float P=x*v* *(ivme+i);
        printf("%s: %f Pascal\n",*(gez+i),P);
    }
}
void kaldirma_kuvveti(float x,float v,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float kk=x*v* *(ivme+i);
        printf("%s: %f Newton\n",*(gez+i),kk);
    }
}
void basit_sarkac(float l,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float T=2*M_PI*sqrt(l/ *(ivme+i));
        printf("%s: %f Saniye\n",*(gez+i),T);
    }
}
void sabit_ip(float m,float *ivme,const char **gez){
    for(int i=0;i<8;i++){
        float T=m* *(ivme+i);
        printf("%s: %f Newton\n",*(gez+i),T);
    }
}
void asansor(float a,float m,float *ivme,const char **gez){
    printf("--Asansor Yukari Hizlaniyorsa Veya Asagi Yavasliyorsa--\n");
    for(int i=0;i<8;i++){
        float N=m*(*(ivme+i)+a);
        printf("%s: %f Newton\n",*(gez+i),N);
    }
    printf("\n--Asansor Yukari Yavasliyorsa Veya Asagi Hizlaniyorsa--\n");
    for(int i=0;i<8;i++){
        float N=m*(*(ivme+i)-a);
        printf("%s: %f Newton\n",*(gez+i),N);
    }
}
int main()
{
    char *isim=(char*)malloc(sizeof(char)*50); //50 karakterlik yer ay�rma
    if(isim==NULL){
        printf("Yer Ayirilamadi!");
        return 1;
    }
    do{
    printf("Lutfen Isminizi Giriniz(1-50 Karakter Araliginda Olmali): ");
    scanf(" %[^\n]s",isim);
    if(strlen(isim)>50||strlen(isim)==0){
        printf("Isim 1-50 Karakter Araliginda Olmali");
    }
    }while(strlen(isim)>50||strlen(isim)==0);
    int n;
    system("cls");
    printf("<<HOSGELDINIZ %s>>\n",isim);
    do{
    printf("\n");
    printf("1.Serbest Dusme Deneyi\n"
           "2.Yukari Atis Deneyi\n"
           "3.Agirlik Deneyi\n"
           "4.Kutlecekimsel Potansiyel Enerji Deneyi\n"
           "5.Hidrostatik Basinc Deneyi\n"
           "6.Arsimet Kaldirma Kuvveti Deneyi\n"
           "7.Basit Sarkac Periyodu Deneyi\n"
           "8.Sabit Ip Gerilmesi Deneyi\n"
           "9.Asansor Deneyi\n"
           "-1.Cikis\n"
           "Istediginiz Deneyi Sayi Ile Secebilirsiniz: ");
    scanf("%d",&n);
    system("cls");
    switch(n){
        case 1:
            float t;
            printf("<<Serbest Dusme Deneyine Hosgeldiniz %s>>\n"
                   "Sureyi Saniye Cinsinden Giriniz: ",isim);
            scanf("%f",&t);
            printf("-Cismin Bu Sure Boyunca Kat Ettigi Yol-\n");
            t=(t<0)?-t:t;
            serbest_dusme(t,cekimIvmeleri,Gezegenler);
            break;
        case 2:
            float v;
            printf("<<Yukari Atis Deneyine Hosgeldiniz %s>>\n"
                   "Hizi Metre/Saniye Cinsinden Giriniz: ",isim);
            scanf("%f",&v);
            v=(v<0)?-v:v;
            printf("-Cismin Maksimum Cikabilecegi Yukseklik-\n");
            yukari_atis(v,cekimIvmeleri,Gezegenler);
            break;
        case 3:
            float m;
            printf("<<Agirlik Deneyine Hosgeldiniz %s>>\n"
                   "Kutleyi Kilogram Cinsinden Giriniz: ",isim);
            scanf("%f",&m);
            m=(m<0)?-m:m;
            printf("-Cismin Agirligi-\n");
            agirlik(m,cekimIvmeleri,Gezegenler);
            break;
        case 4:
            float kutle,h;
            printf("Kutlecekimsel Potansiyel Enerji Deneyine Hosgeldiniz %s>>\n"
                   "Kutleyi Kilogram Cinsinden Giriniz: ",isim);
            scanf("%f",&kutle);
            kutle=(kutle<0)?-kutle:kutle;
            printf("Yuksekligi Metre Cinsinden Giriniz: ");
            scanf("%f",&h);
            h=(h<0)?-h:h;
            printf("-Cismin Kutlecekimsel Potansiyel Enerjisi-\n");
            kPotansiyel(h,kutle,cekimIvmeleri,Gezegenler);
            break;
        case 5:
            float x,derinlik;
            printf("Hidrostatik Basinc Deneyine Hosgeldiniz %s>>\n"
                   "Sivinin Birim Hacmindeki Kutlesini kg/(m^3) Cinsinden Giriniz: ",isim);
            scanf("%f",&x);
            x=(x<0)?-x:x;
            printf("Derinligi Metre Cinsinden Giriniz: ");
            scanf("%f",&derinlik);
            derinlik=(derinlik<0)?-derinlik:derinlik;
            printf("-Cismin Yuzeyine Uygulanan Hidrostatik Basinc-\n");
            hidrobas(x,derinlik,cekimIvmeleri,Gezegenler);
            break;
        case 6:
            float y,Vol;
            printf("Arsimet Kaldirma Kuvveti Deneyine Hosgeldiniz %s>>\n"
                   "Sivinin Birim Hacmindeki Kutlesini kg/(m^3) Cinsinden Giriniz: ",isim);
            scanf("%f",&y);
            y=(y<0)?-y:y;
            printf("Batan Hacmi m^3 Cinsinden Giriniz: ");
            scanf("%f",&Vol);
            Vol=(Vol<0)?-Vol:Vol;
            printf("-Cisme Uygulanan Kaldirma Kuvveti-\n");
            kaldirma_kuvveti(y,Vol,cekimIvmeleri,Gezegenler);
            break;
        case 7:
            float l;
            printf("Basit Sarkac Periyodu Deneyine Hosgeldiniz %s>>\n"
                   "Sarkac Uzunlugunu Metre Cinsinden Giriniz: ",isim);
            scanf("%f",&l);
            l=(l<0)?-l:l;
            printf("-Sarkacin Periyodu-\n");
            basit_sarkac(l,cekimIvmeleri,Gezegenler);
            break;
        case 8:
            float kg;
            printf("Sabit Ip Gerilmesi Deneyine Hosgeldiniz %s>>\n"
                   "Cismin Kutlesini Kilogram Cinsinden Giriniz: ",isim);
            scanf("%f",&kg);
            kg=(kg<0)?-kg:kg;
            printf("-Ipin Gerilme Kuvveti-\n");
            sabit_ip(kg,cekimIvmeleri,Gezegenler);
            break;
        case 9:
            float a_ivme,a_kutle;
            printf("Asansor Deneyine Hosgeldiniz %s>>\n"
                   "Cismin Kutlesini Kilogram Cinsinden Giriniz: ",isim);
            scanf("%f",&a_kutle);
            a_kutle=(a_kutle<0)?-a_kutle:a_kutle;
            printf("Asansor Ivmesini m/(s^2) Cinsinden Giriniz: ");
            scanf("%f",&a_ivme);
            asansor(a_ivme,a_kutle,cekimIvmeleri,Gezegenler);
            break;
        case -1:
            printf("Hoscakalin %s",isim);
            break;
        default:
            printf("HATALI KOMUT!\n");
    }
    }while(n!=-1);
    free(isim);
    return 0;
}
